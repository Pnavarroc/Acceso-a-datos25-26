package org.iesch.ad.Ev2_Hotel.modelo.enums;

/**
 * Tipos de habitación disponibles en el hotel
 */
public enum TipoHabitacion {
    INDIVIDUAL,
    DOBLE,
    SUITE
}

