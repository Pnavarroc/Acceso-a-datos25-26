package org.iesch.ad.Ev2_Hotel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ev2HotelApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ev2HotelApplication.class, args);
	}

}
