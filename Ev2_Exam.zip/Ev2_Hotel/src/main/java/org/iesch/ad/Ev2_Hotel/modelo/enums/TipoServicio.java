package org.iesch.ad.Ev2_Hotel.modelo.enums;

/**
 * Tipos de servicios adicionales disponibles
 */
public enum TipoServicio {
    MINIBAR,
    LAVANDERIA,
    SPA,
    PARKING,
    ROOM_SERVICE
}

