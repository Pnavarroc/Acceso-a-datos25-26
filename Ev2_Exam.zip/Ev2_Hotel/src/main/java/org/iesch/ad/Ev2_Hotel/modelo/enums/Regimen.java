package org.iesch.ad.Ev2_Hotel.modelo.enums;

/**
 * Tipos de régimen de alimentación
 */
public enum Regimen {
    SOLO_ALOJAMIENTO,
    DESAYUNO,
    MEDIA_PENSION,
    PENSION_COMPLETA
}

