package org.iesch.ad.Ev2_Hotel.modelo.enums;

/**
 * Métodos de pago disponibles
 */
public enum MetodoPago {
    EFECTIVO,
    TARJETA,
    TRANSFERENCIA,
    PAYPAL
}

