package org.iesch.ad.Ev2_Hotel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ev2HotelApplicationTests {

	@Test
	void contextLoads() {
	}

}
