package iesch.org.ad.Excepciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExcepcionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExcepcionesApplication.class, args);
	}

}
