package org.iesch.ad.DocumentosReferenciados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocumentosReferenciadosApplicationTests {

	@Test
	void contextLoads() {
	}

}
