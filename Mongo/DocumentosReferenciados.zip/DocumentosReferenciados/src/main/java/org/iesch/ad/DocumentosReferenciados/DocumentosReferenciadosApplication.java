package org.iesch.ad.DocumentosReferenciados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocumentosReferenciadosApplication {

	public static void main(String[] args) {
		SpringApplication.run(DocumentosReferenciadosApplication.class, args);
	}

}
