package org.iesch.ad.demoFechas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoFechasApplicationTests {

	@Test
	void contextLoads() {
	}

}
