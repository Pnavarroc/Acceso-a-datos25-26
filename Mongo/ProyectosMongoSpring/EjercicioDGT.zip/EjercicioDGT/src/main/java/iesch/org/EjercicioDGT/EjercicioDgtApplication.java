package iesch.org.EjercicioDGT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjercicioDgtApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjercicioDgtApplication.class, args);
	}

}
