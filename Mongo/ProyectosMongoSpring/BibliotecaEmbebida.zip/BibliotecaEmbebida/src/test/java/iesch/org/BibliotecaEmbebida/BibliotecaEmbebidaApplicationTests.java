package iesch.org.BibliotecaEmbebida;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaEmbebidaApplicationTests {

	@Test
	void contextLoads() {
	}

}
