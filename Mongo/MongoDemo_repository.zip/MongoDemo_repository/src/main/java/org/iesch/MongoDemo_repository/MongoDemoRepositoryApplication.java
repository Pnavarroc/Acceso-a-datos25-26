package org.iesch.MongoDemo_repository;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongoDemoRepositoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongoDemoRepositoryApplication.class, args);
	}

}
