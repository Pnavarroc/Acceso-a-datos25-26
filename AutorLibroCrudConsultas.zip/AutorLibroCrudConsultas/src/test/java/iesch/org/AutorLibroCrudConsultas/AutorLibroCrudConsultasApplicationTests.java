package iesch.org.AutorLibroCrudConsultas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutorLibroCrudConsultasApplicationTests {

	@Test
	void contextLoads() {
	}

}
