package iesch.org.EjercicioConsultasCoches;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioConsultasCochesApplicationTests {

	@Test
	void contextLoads() {
	}

}
